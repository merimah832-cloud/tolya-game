Place your image files here:
- tolya.png (Character)
- bed1.png (Bed Variant 1)
- bed2.png (Bed Variant 2)
- bed3.png (Bed Variant 3)

If these files are missing, the game will use the fallback SVG graphics.
